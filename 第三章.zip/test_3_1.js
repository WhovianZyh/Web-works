// JavaScript source code
function demo_2() {
    document.getElementById("test_box3").innerHTML="<h1>这是第三个标题</h1>";
    document.getElementById("test_box4").innerHTML="<p>这是第三个段落<p>";
}